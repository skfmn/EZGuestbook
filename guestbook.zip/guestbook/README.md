# EZGuestbook

****************************************
* EZGuestbook V4 copyright 2023 by Steve Frazier
* www.aspjunction.com                              
*                                                   
* You may modify and distribute this script as      
* long as this readme.txt with the copyright header 
* remains with it.                                  
**************************************

*******************Installation Instructions*******************************

Create an MSSQL Database for your guestbook, if your not sure how contact your hosting provider

Upload the guestbook folder to your server and navigate to:

/guestbook/install/install.asp

Then follow the instructions

You will be able to login at:

/guestbook/admin/admin_login.asp

Login using "admin" as your login name AND password. 
Once you have logged in you can and should change your login info.

"/guestbook/sign.asp" is the location of the "Sign Guestbook" page.

"/guestbook/view.asp" is the location of the "View Guestbook" page.

We can install any of the EZCodes for a fee.
If you would like some custom ASP coding done We are available.

Please contact mail@aspjunction.com
